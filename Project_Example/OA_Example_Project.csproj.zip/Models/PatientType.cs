﻿using System;
using System.Collections.Generic;

namespace OA_Example_Project.Models;

public partial class PatientType
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
}
