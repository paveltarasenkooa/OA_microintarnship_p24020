using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OA_Example_Project.Pages
{
    public class TableModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
